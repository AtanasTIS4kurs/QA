﻿namespace PU_Test
{
    public record TestConfiguration(
        string BaseUrl,
        string UsersEndpoint,
        string Token
    );


}
