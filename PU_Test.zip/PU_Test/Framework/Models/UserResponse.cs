﻿namespace PU_Test.Framework.Models
{
    public class UserResponse
    {
        public int id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string gender { get; set; }
        public string status { get; set; }
    }
}
