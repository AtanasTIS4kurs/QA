﻿using System.Net.Http;
using System.Text;
using FluentValidation.Results;
using Newtonsoft.Json;
using PU_Test.Framework.Models;
using PU_Test.Framework.Models.Validator;
using static System.Net.WebRequestMethods;

namespace PU_Test.Tests
{
    [TestFixture]
    public class UsersTest : TestBase
    {
        private string _url = "https://gorest.co.in/public/v2";
        private string _userEndpoint = "/user/7892574";
        private int _id = 7892574;

       
        [Test]
        public async Task CreateUser()
        {
            var requestBody = new UserResponse()
            {
                name = "sds",
                gender = "male",
                email = $"pu-sddsf.{System.Guid.NewGuid()}@example.com",
                status = "active"
            };
            var validator = new UserResponseValidator();
            ValidationResult result = validator.Validate(requestBody);
            if (!result.IsValid)
            {
                var errors = string.Join(", ", result.Errors.Select(e => $"{e.PropertyName}: {e.ErrorMessage}"));
                throw new Exception("Validation failed: " + errors);
            }

            var json = JsonConvert.SerializeObject(requestBody);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await Client.PostAsync("https://gorest.co.in/public/v2/users", content);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"API Error: Status {response.StatusCode}, Response: {responseBody}");
            }
            //var response = await Client.PostAsync("https://gorest.co.in/public/v2/", content);
            //var responseBody = await response.Content.ReadAsStringAsync();
            ////Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.Created), $"Unexpected response: {responseBody}");

        }
    }
}
